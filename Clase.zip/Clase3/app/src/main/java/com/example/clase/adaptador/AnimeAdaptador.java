package com.example.clase.adaptador;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.clase.R;
import com.example.clase.clases.Anime;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AnimeAdaptador extends RecyclerView.Adapter<AnimeAdaptador.ViewHolder> {


    private List<Anime> datos;

    public AnimeAdaptador(List<Anime>datos){
        this.datos = datos;
    }


    @NonNull
    @Override
    public AnimeAdaptador.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_anime,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeAdaptador.ViewHolder holder, int position) {
        Anime dato = datos.get(position);
        holder.bind(dato);


    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView txt_nombre_perso, txt_nombre_anime;
        ImageView img_anime;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_nombre_perso = itemView.findViewById(R.id.txt_nombre_perso);
            txt_nombre_anime = itemView.findViewById(R.id.txt_nombre_anime);
            img_anime = itemView.findViewById(R.id.img_anime);
        }

        public void bind(Anime dato){
            txt_nombre_perso.setText(dato.getNombrePersonajeAnime());
            txt_nombre_anime.setText(dato.getNombreAnime());
            Picasso.get().load(dato.getImagen()).into(img_anime);
        }
    }


}
