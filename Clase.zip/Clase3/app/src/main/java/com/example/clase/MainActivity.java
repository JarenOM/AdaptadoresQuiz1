package com.example.clase;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.clase.adaptador.AnimeAdaptador;
import com.example.clase.clases.Anime;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcv_anime;
    List<Anime> listaAnimes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcv_anime = findViewById(R.id.rcv_anime);

        Anime per1 = new Anime("https://elcomercio.pe/resizer/v2/6Y2EDIISGFGVFANEVDCR5LCG34.jpg?auth=f58b5c647a09717054d85bb8b9a6bc624bfcb14fe9c60b5246730ea6a513e2b0&width=980&height=662&quality=75&smart=true", "Goku", "Dragon Ball");
        Anime per2 = new Anime("https://scontent.fczu1-1.fna.fbcdn.net/v/t39.30808-6/254301408_422399522776799_3392639233295171822_n.jpg?stp=dst-jpg_tt6&cstp=mx741x417&ctp=s741x417&_nc_cat=106&_nc_map=urlgen_bucketless&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeH_GQOzd4-MRd3FCvWE-RBZS6XPG79hPTpLpc8bv2E9OoLgcHIzPY5B8nou3Z1NuctMRN4rtSukXhdXfsolls1-&_nc_ohc=1Tw99E7zPRwQ7kNvwHPoKvW&_nc_oc=AdqYPQrTbYYllu6hTMOlHyGxWT_6Usn_Pv37j_7jU6mBW5JtukrVFLZTYrqyqeSeiRw&_nc_zt=23&_nc_ht=scontent.fczu1-1.fna&_nc_gid=0ZmqsNNftugIeFhEWY3EzA&_nc_ss=7a2a8&oh=00_AQMU7z0JOkPWrlSIG4Gica52-km8m4mxs5WP-PILSZiYqw&oe=6AD83B70", "Ichigo", "Bleach");
        Anime per3 = new Anime("https://img.asmedia.epimg.net/resizer/v2/4DWLBVAQRVA7LNHRR7IMJXARUQ.jpg?auth=85366015ebe9ddb9ab09ceab9bc445609698b044e4a1075268cce909d0e7ce04&width=1440", "Luffy", "One piece");
        Anime per4 = new Anime("https://cmsapi-frontend.naruto-official.com/site/api/naruto/Image/get?path=/naruto/import/images/naruto02/221%EF%BD%9E300/221/C225_0060.jpg", "Naruto", "Naruto");
        Anime per5 = new Anime("https://static0.gamerantimages.com/wordpress/wp-content/uploads/2025/04/solo-leveling-sung-jin-woo-1.jpg?q=70&fit=crop&w=1600&h=1100&dpr=1", "Sung jin woo", "Solo Leveling");
        Anime per6 = new Anime("https://www.thedigitalfix.com/wp-content/sites/thedigitalfix/2023/03/attack-on-titan-what-does-eren-want-550x309.jpg", "Eren", "Shingeki no Kyojin");

        listaAnimes.add(per1);
        listaAnimes.add(per2);
        listaAnimes.add(per3);
        listaAnimes.add(per4);
        listaAnimes.add(per5);
        listaAnimes.add(per6);


        rcv_anime.setLayoutManager(new LinearLayoutManager(this));
        rcv_anime.setAdapter(new AnimeAdaptador(listaAnimes));


        }
    }
