package com.example.clase.clases;

public class Anime {

    private String imagen;
    private String nombrePersonajeAnime;
    private String nombreAnime;

    public Anime(String imagen, String nombrePersonajeAnime, String nombreAnime) {
        this.imagen = imagen;
        this.nombrePersonajeAnime = nombrePersonajeAnime;
        this.nombreAnime = nombreAnime;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getNombrePersonajeAnime() {
        return nombrePersonajeAnime;
    }

    public void setNombrePersonajeAnime(String nombrePersonajeAnime) {
        this.nombrePersonajeAnime = nombrePersonajeAnime;
    }

    public String getNombreAnime() {
        return nombreAnime;
    }

    public void setNombreAnime(String nombreAnime) {
        this.nombreAnime = nombreAnime;
    }
}
